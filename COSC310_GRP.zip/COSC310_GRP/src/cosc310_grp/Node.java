/**
 * S. Saurel, “Calculate shortest paths in Java by implementing Dijkstra's Algorithm,” Medium,
 * 03-Jun-2016. [Online]. Available: https://medium.com/@ssaurel/calculate-shortest-paths-in-java-by-implementing-dijkstras-algorithm-5c1db06b6541. [Accessed: 03-Nov-2017].
 */
package cosc310_grp;

import java.util.ArrayList;

public class Node {

    private double distanceFromSource = Double.POSITIVE_INFINITY;
    private boolean visited;
    private ArrayList<Edge> edges = new ArrayList<Edge>(); // now we must create edges
    

    public double getDistanceFromSource() {
        return distanceFromSource;
    }

    public void setDistanceFromSource(double distanceFromSource) {
        this.distanceFromSource = distanceFromSource;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public ArrayList<Edge> getEdges() {
        return edges;
    }

    public void setEdges(ArrayList<Edge> edges) {
        this.edges = edges;
    }
}
