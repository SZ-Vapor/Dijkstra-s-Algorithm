/**
 * S. Saurel, “Calculate shortest paths in Java by implementing Dijkstra's Algorithm,” Medium,
 * 03-Jun-2016. [Online]. Available: https://medium.com/@ssaurel/calculate-shortest-paths-in-java-by-implementing-dijkstras-algorithm-5c1db06b6541. [Accessed: 03-Nov-2017].
 */
package cosc310_grp;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Edge[] edges = {
            new Edge(0, 1, 4), new Edge(0, 2, 3), new Edge(0, 4, 7),
            new Edge(1, 2, 6), new Edge(1, 3, 5), new Edge(2, 3, 11),
            new Edge(2, 4, 8), new Edge(3, 4, 2), new Edge(4, 6, 5),
            new Edge(3, 6, 10), new Edge(3, 5, 2), new Edge(5, 6, 3),};
        Graph g = new Graph(edges);
        System.out.println("\nNumber of nodes: " + g.getNoOfNodes() + " (0-" + (g.getNoOfNodes() - 1) + ")");
        System.out.println("Number of edges: " + g.getNoOfEdges());

        System.out.print("\nSelect a starting node: ");
        int x = sc.nextInt();
        g.calculateShortestDistances(x);
    }

}
